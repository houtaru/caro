#include <caro.h>

int main() {
    
    Global::load();
    Global::process();
    
    return 0;
}