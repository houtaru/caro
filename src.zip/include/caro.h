#ifndef CARO_H_DEFINED
#define CARO_H_DEFINED

namespace Global {
    void load();

    void process();

    void saveGame();

    void close();
};

#endif